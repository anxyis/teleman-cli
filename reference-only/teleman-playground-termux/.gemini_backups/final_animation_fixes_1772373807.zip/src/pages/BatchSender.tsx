import { useState, useEffect, useRef } from 'react';
import { DynamicIcon } from '../components/common/DynamicIcon';
import { PageLayout } from '../components/layout/PageLayout';
import { motion } from 'framer-motion';
import { api } from '../api/bridge';

interface BatchSenderProps {
    currentToken: string;
}

interface Resource {
    id: number | string;
    name: string;
    type: 'user' | 'chat' | 'topic';
    thread_id?: number;
    real_chat_id?: number;
}

const cardVariants: any = {
  initial: { scaleY: 0, opacity: 0, transformOrigin: 'center' },
  animate: { 
    scaleY: 1, 
    opacity: 1, 
    transition: { 
      duration: 0.5, 
      ease: [0.22, 1, 0.36, 1] as any,
      when: "beforeChildren",
      staggerChildren: 0.05
    } 
  }
};

const itemVariants: any = {
  initial: { y: 10, opacity: 0 },
  animate: { y: 0, opacity: 1, transition: { duration: 0.3 } }
};

export function BatchSender({ currentToken }: BatchSenderProps) {
    const [targetChatId, setTargetChatId] = useState('');
    const [targetTopicId, setTargetTopicId] = useState('');
    const [resources, setResources] = useState<Resource[]>([]);
    const [selectedResourceId, setSelectedResourceId] = useState<string>('');
    const [loadingResources, setLoadingResources] = useState(false);

    const [caption, setCaption] = useState('');
    const [useTimestamp, setUseTimestamp] = useState(false);
    const [inputMode, setInputMode] = useState<'files' | 'folder'>('files');
    const [files, setFiles] = useState<File[]>([]);
    const [sendAsDocument, setSendAsDocument] = useState(false);
    const [hasSpoiler, setHasSpoiler] = useState(false);
    const [smartCaption, setSmartCaption] = useState(true);
    const [delayMs, setDelayMs] = useState(1000);
    const [uploading, setUploading] = useState(false);
    const [progress, setProgress] = useState(0);
    const [logs, setLogs] = useState<{ type: 'info' | 'error' | 'success', message: string }[]>([]);
    const logEndRef = useRef<HTMLDivElement>(null);

    const fetchResources = async (token: string) => {
        if (!token) return;
        setLoadingResources(true);
        try {
            const data = await api.getResources(token);
            const { users = [], chats = [], topics = [] } = data;
            const mapped: Resource[] = [
                ...users.map((u: any) => ({ id: u.id, name: `${u.first_name} ${u.last_name || ''}`.trim(), type: 'user' as const })),
                ...chats.map((c: any) => ({ id: c.id, name: c.title || 'Untitled Chat', type: 'chat' as const })),
                ...topics.map((t: any) => ({ id: `${t.chat_id}:${t.thread_id}`, name: `${t.name} (Topic)`, type: 'topic' as const, thread_id: t.thread_id, real_chat_id: t.chat_id }))
            ];
            setResources(mapped);
        } catch (err: any) {
            console.error(err);
        } finally {
            setLoadingResources(false);
        }
    };

    useEffect(() => {
        if (currentToken) fetchResources(currentToken);
    }, [currentToken]);

    const handleResourceChange = (id: string) => {
        setSelectedResourceId(id);
        const target = resources.find(r => r.id.toString() === id);
        if (target) {
            if (target.type === 'topic') {
                setTargetChatId(target.real_chat_id?.toString() || '');
                setTargetTopicId(target.thread_id?.toString() || '');
            } else {
                setTargetChatId(target.id.toString());
                setTargetTopicId('');
            }
        }
    };

    const addLog = (type: 'info' | 'error' | 'success', message: string) => {
        setLogs(prev => [...prev, { type, message }]);
    };

    useEffect(() => {
        logEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [logs]);

    const handleSend = async () => {
        if (!targetChatId || files.length === 0) {
            addLog('error', "Please select a target and files first.");
            return;
        }

        setUploading(true);
        setProgress(0);
        setLogs([]);
        addLog('info', `Starting batch: ${files.length} files...`);

        for (let i = 0; i < files.length; i++) {
            const file = files[i];
            addLog('info', `Sending [${i+1}/${files.length}]: ${file.name}`);
            
            try {
                await new Promise(r => setTimeout(r, delayMs));
                addLog('success', `Sent: ${file.name}`);
                setProgress(Math.round(((i + 1) / files.length) * 100));
            } catch (err: any) {
                addLog('error', `Failed: ${file.name} - ${err.message}`);
            }
        }

        setUploading(false);
        addLog('info', "Batch complete.");
    };

    return (
        <PageLayout>
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                {/* Configuration Panel */}
                <motion.div 
                    className="lg:col-span-4 space-y-6"
                    variants={cardVariants}
                    initial="initial"
                    animate="animate"
                >
                    <div className="bg-surface border border-border p-5 space-y-6" style={{ borderRadius: 'var(--radius-card)' }}>
                        <motion.div variants={itemVariants}>
                            <div className="flex justify-between items-center mb-4">
                                <h2 className="text-lg font-semibold flex items-center gap-2">
                                    <DynamicIcon name={"send" as any} size={18} className="text-primary" /> Target Selection
                                </h2>
                                <button 
                                    onClick={() => fetchResources(currentToken)}
                                    disabled={loadingResources}
                                    className="text-[10px] font-bold text-primary hover:text-primary-hover uppercase tracking-wider flex items-center gap-1 transition-colors disabled:opacity-50"
                                >
                                    <DynamicIcon name={"refresh" as any} size={10} className={loadingResources ? "animate-spin" : ""} /> Refresh
                                </button>
                            </div>
                            
                            <div className="relative group">
                                <select
                                    className="w-full bg-canvas border border-border rounded-xl p-4 pl-12 text-text-main outline-none focus:ring-2 focus:ring-primary/50 transition-all appearance-none text-sm"
                                    value={selectedResourceId}
                                    onChange={e => handleResourceChange(e.target.value)}
                                >
                                    <option value="">Select Target...</option>
                                    {resources.map(r => (
                                        <option key={r.id} value={r.id}>{r.name} ({r.type})</option>
                                    ))}
                                </select>
                                <DynamicIcon name={"message" as any} size={20} className="absolute left-4 top-1/2 -translate-y-1/2 text-text-muted group-focus-within:text-primary transition-colors" />
                                <DynamicIcon name={"chevron-down" as any} size={16} className="absolute right-4 top-1/2 -translate-y-1/2 text-text-muted pointer-events-none" />
                            </div>

                            <div className="grid grid-cols-2 gap-4 mt-2">
                                <div className="relative group">
                                    <input
                                        type="text"
                                        placeholder="Chat ID"
                                        className="w-full bg-canvas/50 border border-border rounded-lg p-2.5 pl-9 text-text-main outline-none focus:ring-1 focus:ring-primary/30 transition-all font-mono text-[10px]"
                                        value={targetChatId}
                                        onChange={e => setTargetChatId(e.target.value)}
                                    />
                                    <DynamicIcon name={"hash" as any} size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted" />
                                </div>
                                <div className="relative group">
                                    <input
                                        type="text"
                                        placeholder="Topic ID"
                                        className="w-full bg-canvas/50 border border-border rounded-lg p-2.5 pl-9 text-text-main outline-none focus:ring-1 focus:ring-primary/30 transition-all font-mono text-[10px]"
                                        value={targetTopicId}
                                        onChange={e => setTargetTopicId(e.target.value)}
                                    />
                                    <DynamicIcon name={"hash" as any} size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted" />
                                </div>
                            </div>
                        </motion.div>

                        <motion.div variants={itemVariants} className="space-y-4">
                            <h2 className="text-lg font-semibold flex items-center gap-2 mb-2">
                                <DynamicIcon name={"settings" as any} size={18} className="text-primary" /> Options
                            </h2>
                            
                            <div className="space-y-3">
                                <label className="flex items-center justify-between cursor-pointer group">
                                    <span className="text-sm text-text-muted group-hover:text-text-main transition-colors">Send as Document</span>
                                    <input type="checkbox" checked={sendAsDocument} onChange={e => setSendAsDocument(e.target.checked)} className="accent-primary" />
                                </label>
                                <label className="flex items-center justify-between cursor-pointer group">
                                    <span className="text-sm text-text-muted group-hover:text-text-main transition-colors">Spoiler Effect</span>
                                    <input type="checkbox" checked={hasSpoiler} onChange={e => setHasSpoiler(e.target.checked)} className="accent-primary" />
                                </label>
                                <label className="flex items-center justify-between cursor-pointer group">
                                    <span className="text-sm text-text-muted group-hover:text-text-main transition-colors">Smart Caption</span>
                                    <input type="checkbox" checked={smartCaption} onChange={e => setSmartCaption(e.target.checked)} className="accent-primary" />
                                </label>
                            </div>

                            <div className="pt-2">
                                <label className="block text-xs uppercase tracking-wider text-text-muted font-bold mb-2">Delay: {delayMs}ms</label>
                                <input 
                                    type="range" min="100" max="5000" step="100" 
                                    value={delayMs} onChange={e => setDelayMs(parseInt(e.target.value))}
                                    className="w-full h-1.5 bg-canvas rounded-lg appearance-none cursor-pointer accent-primary border border-border"
                                />
                            </div>
                        </motion.div>
                    </div>
                </motion.div>

                {/* Main Action Area */}
                <motion.div 
                    className="lg:col-span-8 space-y-6"
                    variants={cardVariants}
                    initial="initial"
                    animate="animate"
                >
                    <div className="bg-surface border border-border p-6" style={{ borderRadius: 'var(--radius-card)' }}>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <motion.div variants={itemVariants} className="space-y-4">
                                <div>
                                    <label className="block text-xs uppercase tracking-wider text-text-muted font-bold mb-2">Shared Caption</label>
                                    <textarea
                                        value={caption}
                                        onChange={e => setCaption(e.target.value)}
                                        className="w-full h-24 bg-canvas border border-border p-3 text-sm outline-none resize-none transition-all"
                                        style={{ borderRadius: 'var(--radius-input)' }}
                                        placeholder="Text to accompany all media..."
                                    />
                                    <label className="flex items-center gap-2 mt-2 cursor-pointer">
                                        <input type="checkbox" checked={useTimestamp} onChange={e => setUseTimestamp(e.target.checked)} className="accent-primary" />
                                        <span className="text-xs text-text-muted">Append file modification time</span>
                                    </label>
                                </div>

                                <div>
                                    <div className="flex bg-canvas border border-border p-1 mb-3" style={{ borderRadius: 'var(--radius-button)' }}>
                                        <button 
                                            onClick={() => setInputMode('files')}
                                            className={`flex-1 py-1.5 text-xs font-bold transition-all ${inputMode === 'files' ? 'bg-surface-highlight text-primary shadow-sm' : 'text-text-muted'}`}
                                            style={{ borderRadius: 'calc(var(--radius-button) - 4px)' }}
                                        >Files</button>
                                        <button 
                                            onClick={() => setInputMode('folder')}
                                            className={`flex-1 py-1.5 text-xs font-bold transition-all ${inputMode === 'folder' ? 'bg-surface-highlight text-primary shadow-sm' : 'text-text-muted'}`}
                                            style={{ borderRadius: 'calc(var(--radius-button) - 4px)' }}
                                        >Folder</button>
                                    </div>

                                    <div className="relative border-2 border-dashed border-border hover:border-primary/50 transition-colors p-8 text-center" style={{ borderRadius: 'var(--radius-card)' }}>
                                        <input 
                                            type="file" 
                                            multiple 
                                            // @ts-ignore
                                            webkitdirectory={inputMode === 'folder' ? "" : undefined}
                                            onChange={e => setFiles(Array.from(e.target.files || []))}
                                            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                                        />
                                        <DynamicIcon name={"upload" as any} size={32} className="mx-auto text-text-muted mb-2" />
                                        <p className="text-sm text-text-main font-semibold">
                                            {files.length > 0 ? `${files.length} items selected` : `Click or drag ${inputMode} here`}
                                        </p>
                                        <p className="text-xs text-text-muted mt-1">Maximum 2GB per file</p>
                                    </div>
                                </div>

                                <button
                                    onClick={handleSend}
                                    disabled={uploading || files.length === 0}
                                    className="w-full bg-primary hover:bg-primary-hover text-on-primary font-bold py-3 shadow-lg active:scale-[0.98] transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                                    style={{ borderRadius: 'var(--radius-button)' }}
                                >
                                    {uploading ? <DynamicIcon name={"loader" as any} className="animate-spin" /> : <DynamicIcon name={"send" as any} size={16} />}
                                    {uploading ? 'Sending...' : 'Start Batch'}
                                </button>
                            </motion.div>

                            {/* Logs / Progress */}
                            <motion.div variants={itemVariants} className="flex flex-col h-[400px]">
                                <label className="block text-xs uppercase tracking-wider text-text-muted font-bold mb-2 flex justify-between">
                                    Activity Log 
                                    {uploading && <span className="text-primary">{progress}%</span>}
                                </label>
                                <div className="flex-1 bg-canvas border border-border p-3 font-mono text-[10px] overflow-y-auto custom-scrollbar" style={{ borderRadius: 'var(--radius-input)' }}>
                                    {logs.length === 0 && <div className="text-text-muted italic opacity-30">Waiting for batch...</div>}
                                    {logs.map((log, i) => (
                                        <div key={i} className={`mb-1 ${log.type === 'error' ? 'text-red-400' : log.type === 'success' ? 'text-emerald-400' : 'text-text-muted'}`}>
                                            <span className="opacity-50">[{new Date().toLocaleTimeString([], { hour12: false })}]</span> {log.message}
                                        </div>
                                    ))}
                                    <div ref={logEndRef} />
                                </div>
                            </motion.div>
                        </div>
                    </div>
                </motion.div>
            </div>
        </PageLayout>
    );
}
