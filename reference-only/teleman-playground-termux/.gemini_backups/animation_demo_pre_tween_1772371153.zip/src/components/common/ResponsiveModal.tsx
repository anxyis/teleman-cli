import React, { useEffect } from 'react';
import { createPortal } from 'react-dom';
import { DynamicIcon } from './DynamicIcon';
import { motion, AnimatePresence } from 'framer-motion';

interface ResponsiveModalProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  description?: string;
  children: React.ReactNode;
  actions?: React.ReactNode;
  widthClass?: string;
}

export function ResponsiveModal({
  isOpen,
  onClose,
  title,
  description,
  children,
  actions,
  widthClass = 'max-w-2xl'
}: ResponsiveModalProps) {
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => { document.body.style.overflow = ''; };
  }, [isOpen]);

  return createPortal(
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-end md:items-center justify-center p-0 md:p-4">
          {/* Backdrop */}
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            onClick={onClose}
          />

          {/* Modal Container */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ type: "spring", stiffness: 400, damping: 40 }}
            className={`
              relative w-full h-full md:h-auto md:max-h-[85vh] ${widthClass}
              bg-surface shadow-2xl overflow-hidden flex flex-col border border-border/20
              focus:outline-none transition-all
            `}
            style={{ borderRadius: 'var(--radius-modal)' }}
            tabIndex={-1}
          >

            {/* Header */}
            <div className="p-4 border-b border-border flex justify-between items-center shrink-0 bg-surface z-10 sticky top-0">
              <div>
                {title && <h2 className="text-lg font-bold text-text-main leading-tight">{title}</h2>}
                {description && <p className="text-sm text-text-muted mt-0.5">{description}</p>}
              </div>
              <button
                onClick={onClose}
                className="p-2 hover:bg-surface-highlight text-text-muted hover:text-text-main rounded-xl transition-colors"
              >
                <DynamicIcon name="x" size={20} />
              </button>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto p-4 md:p-6 custom-scrollbar bg-canvas/30">
              {children}
            </div>

            {/* Actions Footer */}
            {actions && (
              <div className="p-4 border-t border-border bg-surface shrink-0 z-10">
                {actions}
              </div>
            )}

            {/* Mobile Safe Area Spacer (if no actions) */}
            {!actions && <div className="h-safe md:hidden bg-surface" />}
          </motion.div>
        </div>
      )}
    </AnimatePresence>,
    document.body
  );
}
