import React, { useState, useEffect } from 'react';
import { ModernHeader } from '../components/ModernHeader';
import { ModernBottomNav } from '../components/ModernBottomNav';
import { ModernSidebar } from '../components/navigation/ModernSidebar';
import { BotSelector } from '../components/BotSelector';

interface AppLayoutProps {
  children: React.ReactNode;
  activeToken: string;
  savedBots: any[];
  onBotChange: () => void;
  onOpenSettings: () => void;
}

export function AppLayout({ children, activeToken, savedBots, onBotChange, onOpenSettings }: AppLayoutProps) {
  const [invertedLayout, setInvertedLayout] = useState(() => localStorage.getItem('invertedLayout') === 'true');

  useEffect(() => {
    const handleSettingsChange = (e: CustomEvent) => {
      if (e.detail.invertedLayout !== undefined) setInvertedLayout(e.detail.invertedLayout);
    };
    window.addEventListener('settingsChanged', handleSettingsChange as EventListener);
    return () => window.removeEventListener('settingsChanged', handleSettingsChange as EventListener);
  }, []);

  return (
    <div className="min-h-screen bg-canvas text-text-main transition-colors duration-300 flex flex-col">
      {/* Desktop Sidebar (lg:flex) */}
      <ModernSidebar onOpenSettings={onOpenSettings}>
          <BotSelector
             currentBotToken={activeToken}
             savedBots={savedBots}
             onBotChange={onBotChange}
             onOpenSettings={onOpenSettings}
          />
      </ModernSidebar>

      {/* Mobile Top Element */}
      <div className="lg:hidden shrink-0">
          {invertedLayout ? (
            <ModernBottomNav position="top" />
          ) : (
            <ModernHeader
                activeToken={activeToken}
                savedBots={savedBots}
                onBotChange={onBotChange}
                onOpenSettings={onOpenSettings}
            />
          )}
      </div>

      {/* Main Content Wrapper */}
      <div className="lg:pl-[var(--w-sidebar-desktop,256px)] transition-all duration-300 flex-1 flex flex-col">
        {/* Content */}
        <main className={`flex-1 w-full max-w-7xl mx-auto p-0 lg:pb-0 ${invertedLayout ? 'pt-[var(--h-nav-mobile,96px)]' : 'pb-[var(--h-nav-mobile,96px)]'}`}>
            {children}
        </main>
      </div>

      {/* Mobile Bottom Element */}
      <div className="lg:hidden">
          {invertedLayout ? (
            <ModernHeader
                activeToken={activeToken}
                savedBots={savedBots}
                onBotChange={onBotChange}
                onOpenSettings={onOpenSettings}
            />
          ) : (
            <ModernBottomNav position="bottom" />
          )}
      </div>
    </div>
  );
}
