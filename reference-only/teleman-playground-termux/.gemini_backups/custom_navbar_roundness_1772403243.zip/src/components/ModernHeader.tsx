import { DynamicIcon } from './common/DynamicIcon';
import { BotSelector } from './BotSelector';
import { useLocation } from 'react-router-dom';
import { AnimatedText } from './common/AnimatedText';

interface ModernHeaderProps {
  activeToken: string;
  savedBots: any[];
  onBotChange: () => void;
  onOpenSettings: () => void;
}

export function ModernHeader({ activeToken, savedBots, onBotChange, onOpenSettings }: ModernHeaderProps) {
  const location = useLocation();

  let title = "TeleMan";
  if (location.pathname === '/') title = "Playground";
  else if (location.pathname === '/batch') title = "Batch"; // Shorter for mobile
  else if (location.pathname.startsWith('/autosyncer')) title = "Sync"; // Shorter for mobile

  const SettingsButton = ({ className }: { className?: string }) => (
    <button
      onClick={onOpenSettings}
      className={`p-2 text-text-muted hover:text-text-main hover:bg-surface-highlight rounded-xl transition-colors ${className}`}
      aria-label="Settings"
    >
      <DynamicIcon name="settings" size={20} />
    </button>
  );

  return (
    <header className="sticky top-0 z-50 bg-canvas/80 backdrop-blur-xl border-b border-border px-4 h-16 flex items-center justify-between transition-all duration-300">
       {/* Left: Brand & Title */}
       <div className="flex items-center gap-3 min-w-0">
           <div className="p-2 bg-primary/20 rounded-xl text-primary shrink-0">
             <DynamicIcon name="terminal" size={18} />
           </div>
           <h1 className="font-bold text-base tracking-tight text-text-main truncate">
             <AnimatedText text={title} key={title} />
           </h1>
       </div>

       {/* Right: Actions */}
       <div className="flex items-center gap-2 shrink-0">
           <div className="flex items-center gap-2">
             <BotSelector
               currentBotToken={activeToken}
               savedBots={savedBots}
               onBotChange={onBotChange}
               onOpenSettings={onOpenSettings}
               isCompact={true}
             />
             <SettingsButton />
           </div>
       </div>
    </header>
  );
}
