import { useState, useEffect, useLayoutEffect } from 'react';
import { api } from './api/bridge';
import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom';
import { Playground } from './pages/Playground';
import { BatchSender } from './pages/BatchSender';
import { AutoSyncer } from './pages/AutoSyncer';
import { SettingsModal } from './components/SettingsModal';
import { LogsPage } from './pages/LogsPage';
import { WelcomeScreen } from './components/WelcomeScreen';
import { ThemeProvider } from './context/ThemeContext';
import { AppLayout } from './layouts/AppLayout';
import { motion, AnimatePresence } from 'framer-motion';

const routeOrder = ['/', '/batch', '/autosyncer', '/autosyncer/logs'];

function ScrollToTop() {
  const { pathname } = useLocation();
  useLayoutEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
  }, [pathname]);
  return null;
}

function AnimatedRoutes({ activeToken, loadingConfig, savedBots, fetchConfig }: any) {
  const location = useLocation();
  const [prevIndex, setPrevIndex] = useState(0);
  const currentIndex = routeOrder.indexOf(location.pathname);
  const direction = currentIndex >= prevIndex ? 1 : -1;

  useLayoutEffect(() => {
    setPrevIndex(currentIndex);
  }, [currentIndex]);

  const variants: any = {
    initial: (dir: number) => ({
      x: dir > 0 ? 30 : -30,
      opacity: 0,
      position: 'absolute',
      inset: 0
    }),
    animate: {
      x: 0,
      opacity: 1,
      position: 'relative',
      transition: { duration: 0.4, ease: [0.4, 0, 0.2, 1] as any }
    },
    exit: (dir: number) => ({
      x: dir > 0 ? -30 : 30,
      opacity: 0,
      position: 'absolute',
      inset: 0,
      transition: { duration: 0.3 }
    })
  };

  return (
    <AnimatePresence mode="popLayout" custom={direction} initial={false}>
      <motion.div
        key={location.pathname}
        custom={direction}
        variants={variants}
        initial="initial"
        animate="animate"
        exit="exit"
        className="w-full min-h-full overflow-x-hidden"
      >
        {loadingConfig ? (
          <div className="flex h-[50vh] items-center justify-center text-text-muted">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        ) : (savedBots.length === 0) ? (
          <WelcomeScreen onAddBot={fetchConfig} />
        ) : (
          <Routes location={location}>
            <Route path="/" element={<Playground currentToken={activeToken} />} />
            <Route path="/batch" element={<BatchSender currentToken={activeToken} />} />
            <Route path="/autosyncer" element={<AutoSyncer />} />
            <Route path="/autosyncer/logs" element={<LogsPage />} />
          </Routes>
        )}
      </motion.div>
    </AnimatePresence>
  );
}

function AppContent() {
  const [activeToken, setActiveToken] = useState('');
  const [savedBots, setSavedBots] = useState([]);
  const [showSettings, setShowSettings] = useState(false);
  const [loadingConfig, setLoadingConfig] = useState(true);

  const fetchConfig = async () => {
    try {
      const config = await api.getConfig();
      setActiveToken(config.activeToken);
      setSavedBots(config.savedBots as never[]);
    } catch (e) {
      console.error("Failed to fetch config", e);
    } finally {
      setLoadingConfig(false);
    }
  };

  useEffect(() => {
    fetchConfig();
  }, []);

  return (
    <BrowserRouter>
      <ScrollToTop />
      <AppLayout
        activeToken={activeToken}
        savedBots={savedBots}
        onBotChange={fetchConfig}
        onOpenSettings={() => setShowSettings(true)}
      >
        <AnimatedRoutes 
          activeToken={activeToken} 
          loadingConfig={loadingConfig} 
          savedBots={savedBots} 
          fetchConfig={fetchConfig} 
        />
      </AppLayout>

      <SettingsModal
        isOpen={showSettings}
        onClose={() => setShowSettings(false)}
      />
    </BrowserRouter>
  );
}

function App() {
  return (
    <ThemeProvider>
      <AppContent />
    </ThemeProvider>
  );
}

export default App;
