import { NavLink } from 'react-router-dom';
import { DynamicIcon } from './common/DynamicIcon';

export function ModernBottomNav() {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-surface/90 backdrop-blur-xl border-t border-border pb-safe">
      <div className="flex justify-around items-center h-20">
        <NavLink
          to="/"
          className={({ isActive }) => `flex flex-col items-center gap-1 p-2 w-16 transition-all active:scale-90 ${isActive ? 'text-primary' : 'text-text-muted hover:text-text-main'}`}
        >
          {() => (
            <>
              <DynamicIcon name="dashboard" size={24} />
              <span className="text-[10px] font-medium">Play</span>
            </>
          )}
        </NavLink>

        <NavLink
          to="/batch"
          className={({ isActive }) => `flex flex-col items-center gap-1 p-2 w-16 transition-all active:scale-90 ${isActive ? 'text-primary' : 'text-text-muted hover:text-text-main'}`}
        >
          {() => (
            <>
              <DynamicIcon name="folders" size={24} />
              <span className="text-[10px] font-medium">Batch</span>
            </>
          )}
        </NavLink>

        <NavLink
          to="/autosyncer"
          className={({ isActive }) => `flex flex-col items-center gap-1 p-2 w-16 transition-all active:scale-90 ${isActive ? 'text-primary' : 'text-text-muted hover:text-text-main'}`}
        >
          {() => (
            <>
              <DynamicIcon name="settings" size={24} />
              <span className="text-[10px] font-medium">Sync</span>
            </>
          )}
        </NavLink>
      </div>
    </nav>
  );
}

