import { useState, useRef, useEffect } from 'react';
import { HexColorPicker, HexColorInput } from 'react-colorful';
import { Palette, X } from 'lucide-react';

interface BetterColorPickerProps {
    color: string;
    onChange: (color: string) => void;
    label?: string;
    presets?: string[];
}

const DEFAULT_PRESETS = [
    '#BB86FC', // Primary (Amoled)
    '#2563eb', // Primary (Classic)
    '#ffffff', 
    '#000000',
    '#121212',
    '#ef4444', // Red
    '#22c55e', // Green
    '#f59e0b', // Amber
    '#3b82f6', // Blue
    '#8b5cf6', // Violet
    '#ec4899', // Pink
];

export function BetterColorPicker({ color, onChange, label, presets = DEFAULT_PRESETS }: BetterColorPickerProps) {
    const [isOpen, setIsOpen] = useState(false);
    const popoverRef = useRef<HTMLDivElement>(null);

    const toggle = () => setIsOpen(!isOpen);
    const close = () => setIsOpen(false);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (popoverRef.current && !popoverRef.current.contains(event.target as Node)) {
                close();
            }
        };

        if (isOpen) {
            document.addEventListener('mousedown', handleClickOutside);
        } else {
            document.removeEventListener('mousedown', handleClickOutside);
        }

        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, [isOpen]);

    return (
        <div className="relative w-full">
            {label && (
                <span className="text-[10px] text-text-muted truncate capitalize block mb-1">
                    {label.replace(/([A-Z])/g, ' $1')}
                </span>
            )}
            
            <div className="flex items-center gap-2 bg-surface-highlight p-1.5 rounded-xl border border-white/5 hover:border-white/10 transition-colors">
                <button
                    onClick={toggle}
                    className="w-8 h-8 rounded-lg shadow-inner border border-white/10 flex-shrink-0 transition-transform active:scale-90"
                    style={{ backgroundColor: color }}
                    title="Open color picker"
                />
                
                <div className="flex-1 flex items-center gap-2 px-1">
                    <HexColorInput
                        color={color}
                        onChange={onChange}
                        className="bg-transparent text-[10px] font-mono uppercase text-text-main outline-none w-full"
                    />
                </div>

                <button 
                    onClick={toggle}
                    className="p-1.5 text-text-muted hover:text-text-main transition-colors"
                >
                    <Palette size={14} />
                </button>
            </div>

            {isOpen && (
                <div 
                    ref={popoverRef}
                    className="absolute z-50 mt-2 p-3 bg-surface border border-border rounded-2xl shadow-2xl animate-in fade-in zoom-in-95 duration-200 origin-top-left"
                    style={{ minWidth: '220px' }}
                >
                    <div className="flex items-center justify-between mb-3 border-b border-border/50 pb-2">
                        <span className="text-[10px] font-bold text-text-muted uppercase tracking-wider">Color Picker</span>
                        <button onClick={close} className="text-text-muted hover:text-text-main">
                            <X size={14} />
                        </button>
                    </div>

                    <div className="space-y-4">
                        <div className="better-picker-wrapper">
                            <HexColorPicker color={color} onChange={onChange} />
                        </div>

                        <div className="space-y-2">
                            <div className="flex items-center gap-2 bg-surface-highlight p-2 rounded-lg border border-border/50">
                                <div 
                                    className="w-4 h-4 rounded shadow-sm border border-white/10" 
                                    style={{ backgroundColor: color }} 
                                />
                                <HexColorInput
                                    color={color}
                                    onChange={onChange}
                                    className="bg-transparent text-xs font-mono uppercase text-text-main outline-none flex-1"
                                    prefixed
                                />
                            </div>

                            <div className="grid grid-cols-6 gap-1.5">
                                {presets.map((p) => (
                                    <button
                                        key={p}
                                        className={`w-full aspect-square rounded-md border border-white/10 transition-transform hover:scale-110 active:scale-90 ${color.toLowerCase() === p.toLowerCase() ? 'ring-2 ring-primary ring-offset-2 ring-offset-surface' : ''}`}
                                        style={{ backgroundColor: p }}
                                        onClick={() => onChange(p)}
                                    />
                                ))}
                            </div>
                        </div>
                    </div>
                </div>
            )}

            <style>{`
                .better-picker-wrapper .react-colorful {
                    width: 100%;
                    height: 160px;
                    border-radius: 12px;
                }
                .better-picker-wrapper .react-colorful__saturation {
                    border-bottom: none;
                    border-radius: 12px 12px 0 0;
                }
                .better-picker-wrapper .react-colorful__hue {
                    height: 12px;
                    border-radius: 0 0 12px 12px;
                }
                .better-picker-wrapper .react-colorful__pointer {
                    width: 18px;
                    height: 18px;
                }
            `}</style>
        </div>
    );
}
