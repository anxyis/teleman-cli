# Unit-1

### Q1 - What do you mean by Human Resource Management? Also discuss the various roles of Human Resource Management

Human Resource Management (HRM) can be broadly understood as the **function within an organization that focuses on the recruitment, management, and direction of the people who work in that organization**. It involves developing a consistent and aligned set of practices, programs, and policies to facilitate the achievement of the organization’s strategic objectives by effectively managing its employees. Strategic HRM recognizes that an organization's people are crucial to its success, as they are the ones making decisions related to all aspects of the business.

The role of HRM has evolved significantly from a traditional, administrative focus to a more strategic one. Here are various roles that HRM assumes within organizations, as highlighted in the sources:

**Evolving/Strategic Roles of Human Resource Management:**

- **Strategic Partner:** HR collaborates with senior and line managers in the execution of the organization's strategy. This involves understanding the business strategy and ensuring that the organizational structure and HR practices are aligned to support it. HR in this role conducts organizational audits to identify necessary changes and sets priorities to deliver results.
- **Change Agent:** HR plays a critical role in building the organization's capacity to embrace and capitalize on change. This includes defining, developing, and delivering change initiatives and helping the organization plan for and overcome resistance to change, especially concerning organizational culture.
- **Employee Champion:** HR acts as an advocate for employees, working to increase their contribution and commitment to the organization. This involves understanding employee needs and creating a work environment that fosters engagement, satisfaction, and trust.
- **Administrative Expert:** While the focus shifts towards strategic activities, HR remains responsible for ensuring efficiency through reengineering processes and serving as an expert in administrative functions. This includes managing compliance with employment laws and handling essential administrative tasks.
- **Human Capital Steward:** This role involves creating an environment and culture where employees voluntarily contribute their skills, ideas, and energy, recognizing that human capital is not owned by the organization and can move freely.
- **Knowledge Facilitator:** HR plays a role in facilitating the sharing and utilization of knowledge within the organization.
- **Relationship Builder:** HR is involved in building strong relationships both internally and potentially externally.
- **Rapid Deployment Specialist:** HR needs to be able to quickly implement HR solutions as needed by the organization.
- **"Chief Financial Officer" for HR:** Some suggest a specialized role focused on HR metrics and financial analysis to demonstrate the cost-effectiveness of HR programs.
- **"Internal Consultant":** Another specialized role involves training and empowering line managers to handle many day-to-day employee management responsibilities.
- **"Talent Manager":** This specialized role focuses on finding, developing, and retaining the optimal mix of employees to achieve strategic objectives.
- **"Vendor Manager":** HR may also specialize in determining which HR functions should be outsourced and managing those vendor relationships.
- **"Self-Service Manager":** This role oversees the technology applications of HR management, including e-HR.

**Shift in Responsibility:**

- Strategic HRM emphasizes that the responsibility for managing people should not solely rest with HR specialists but should be shared with **line managers** who are in direct contact with employees. In this view, anyone with responsibility for people is considered an HR manager.

**Traditional Aspects (though often evolving within Strategic HR):**

- **Staffing:** This includes recruiting and selecting employees to meet the organization's needs, which is a strategic issue.
- **Training and Development:** Organizing procedures for employees to learn knowledge and skills for specific jobs and for their growth and development within the organization.
- **Performance Management and Feedback:** Systematically evaluating employee performance against established standards and providing feedback for improvement.
- **Compensation:** Designing and administering reward systems that are commensurate with employee contributions and support organizational goals.
- **Labor Relations:** Managing the relationship between the employer and employees, especially in unionized environments.
- **Employee Separation and Retention Management:** Addressing employee turnover and implementing strategies to retain valuable employees.
- **Discipline and Grievance Handling:** Establishing orderly forces to ensure adherence to rules and regulations and managing employee grievances.
- **Ensuring Legal Compliance:** Adhering to employment laws and regulations.

 HRM in its strategic form is about **integrating the human element into the overall business strategy** to achieve a competitive advantage. It involves viewing employees as valuable assets and making investments in them to enhance their value to the organization.

### Q2 - Write short notes on: 

#### 1- Job Analysis 

**1- Job Analysis**

- **Job Analysis is a systematic way to gather and analyze information about the content of jobs**.
- The job analysis process should identify the job under review, the participants involved, existing documentation (including the existing job description), the identification of the major job content domains contained within the job, and a developed list of tasks to be fulfilled under each domain.
- Conducting a thorough job analysis helps to define the appropriate content domains and tasks for job descriptions.
- **Performance standards can flow directly from a job description**, which is informed by job analysis.
- Researchers have suggested conducting a thorough job analysis to define the appropriate content domains and tasks for job descriptions.
- In practice, to complete a job analysis, a meeting can be conducted between the employee and their supervisor to review the current job description and brainstorm job domains and tasks, possibly comparing with similar positions from other agencies.
- Once job domains and tasks are identified, they can be weighted to describe their significance in terms of importance and time/frequency.
- **Content validity**, which illustrates that a measure or criterion is representative of the actual job content and/or desired knowledge, is determined through the process of job analysis.

#### 2- Delphi Technique

**Definition and Purpose**  
The Delphi Technique is a structured communication method used to gather expert opinions and reach a consensus on complex issues. Developed in the 1960s, it is particularly useful in project management for decision-making related to scope and risk management. This technique allows for systematic feedback from experts while minimizing the influence of dominant individuals in group discussions.

**Process of the Delphi Technique**

1. **Initial Round of Questions**: Experts provide their opinions on a specific issue through questionnaires.
    
2. **Compilation of Responses**: A facilitator summarizes the responses and shares them with all participants.
    
3. **Subsequent Rounds**: Experts review the summary and can revise their opinions based on collective feedback. This process continues until a consensus is reached or sufficient information has been gathered.
    

**Applications in Project Management**  
The Delphi Technique is valuable in defining project scopes and managing risks by allowing stakeholders to voice their insights without bias. It helps ensure that all perspectives are considered before making critical decisions, thereby enhancing project outcomes.

In summary, both job analysis and the Delphi Technique play essential roles in human resource management by facilitating informed decision-making and aligning organizational needs with employee capabilities.

---

# Unit-2

#### Q3 - Define Recruitment and describe in detail the various sources of Recruitment.

Recruitment can be defined as the **process of actively seeking out and attracting a pool of qualified candidates** to fill job vacancies within an organization. It is a key strategic area for human resource management because the quality of the individuals recruited directly impacts an organization's performance and success. The messages conveyed during recruitment can also influence future employees' engagement and commitment.

There are various sources of recruitment, which can be broadly categorized as **internal** and **external**.

**Internal Sources of Recruitment:**

- **Current Employees:** Recruiting from the current employee pool can offer several benefits.
    - The organization already possesses **performance data** on these employees, including their work habits, skills, capabilities, ability to collaborate, and alignment with the organizational culture.
    - It can **boost employee morale** by signaling commitment reciprocity and providing opportunities for growth and advancement.
    - Internal recruitment generally involves **less training and socialization time** as the employees are already familiar with the organization.
    - It can be a **faster and less expensive** method compared to external recruitment.
- **Formal Job Posting:** Most larger organizations utilize a formal job posting system for internal recruitment. This involves **advertising the available position** in accessible locations, such as physical or online bulletin boards, allowing employees to apply if interested. Organizations may also use their HR information systems, including **skills inventories** in computerized databases, to identify internal candidates with the required skills and experience. These candidates can then be contacted to gauge their interest.
- **Employee Referrals:** Organizations may have programs that offer **bonuses to current employees** who recommend friends or family members for jobs. Employees hired through referrals tend to have better retention rates. However, relying solely on word-of-mouth can limit diversity.
- **Career Connection (Internal Talent Pool):** Some organizations, like Cisco Systems, maintain internal databases of "passive candidates" – employees who have registered their interest in future opportunities. Recruiting from such pools can save on search firm fees and raise employee satisfaction.

**External Sources of Recruitment:**

- **Advertising:** Positions can be advertised broadly through various media.
    - **Traditional Media:** This includes placing advertisements in newspapers and other publications. However, fewer than 20 percent of those who read help-wanted ads may be actively seeking employment.
    - **Internet Recruiting:** This has become one of the fastest-growing methods due to its low cost, speed, and ability to target applicants with specific skills. Most HR professionals use the internet for recruiting, finding it more cost-effective than newspaper ads. However, poorly designed websites can damage an organization's reputation. Internet recruiting offers global exposure but can also lead to a disparate impact against certain protected classes who may have less internet access. Social networking sites like LinkedIn and Facebook are also widely used for recruitment, although their user demographics might skew the applicant pool. Employers use the internet significantly to attract **"passive job candidates"** who are not actively looking.
- **Employment Agencies (Staffing Agencies/Services):** These agencies specialize in locating and prescreening applicants for employers. They can save organizations time and money, especially for time-consuming screening processes, and may offer a more objective perspective.
- **State Job Service Agencies:** These publicly funded agencies, operated by individual states, require those filing for unemployment to register and seek work. Employers can list positions with these agencies for free.
- **College and University On-Campus Recruiting:** This method can generate a large pool of motivated, skilled, and energetic applicants in a short period at a minimal cost. However, these applicants often have limited work experience and are available only at certain times of the year.
- **Informal Recruiting:** This can occur through contacts with friends and acquaintances of existing employees, particularly in smaller organizations or at the executive level, where peer networking is common.
- **Recruiting from Competitors, Suppliers, Customers, or Regulators:** While HR managers should avoid encouraging disloyalty or breach of non-compete agreements, they should respect the autonomy of potential employees to leave their current employers. Recruiting from an organization's customer base can be convenient, cost-effective, and result in enthusiastic employees who already believe in the organization. Former employees ("boomerang employees") are another often overlooked source of recruitment.
- **Outsourced Recruiting:** Organizations may outsource all or part of their recruiting function to external vendors for increased flexibility and alignment with business needs, especially in cyclical industries.
- **Executive Search Firms ("Headhunters"):** These firms specialize in recruiting for senior-level positions.
- **Internship Programs:** Internships can serve as a recruitment tool for identifying and attracting potential future employees.
- **Job Fairs:** Attending job fairs allows organizations to collect resumes and conduct impromptu interviews, educating job seekers about temporary and permanent opportunities.

**Active vs. Passive Recruiting:**

- **Passive Recruiting:** Involves simply posting and/or advertising openings and waiting for applications, often chosen to attract a diverse pool in line with EEOC guidelines, though results in attracting the best candidates may vary.
- **Active Recruiting:** Involves proactively targeting specific individuals within professional networks through conferences, trade shows, networking events, and social media to ensure the best and broadest applicant pool, including those not actively seeking new roles.

Effective recruiting requires careful planning and strategizing to ensure the organization attracts the right employees with the right skills at the right time. Organizations may use **yield ratios** from past recruiting efforts to determine the necessary size of the applicant pool. They also need to determine the optimal time to begin recruiting to have trained employees ready when needed.

Ultimately, the choice of recruitment sources depends on the organization's strategy, needs, resources, and the nature of the positions being filled. A strategic approach to recruitment aims to create an optimal fit between employees and the organization's strategic needs.


#### Q4 What is Training? Discuss the various techniques of Training.

**What is Training?**

**Training is an organized procedure through which people learn knowledge and/or skill for a definite purpose**. It refers to the **teaching and learning activities carried on for the primary purpose of helping members of an organization acquire and apply the knowledge, skills, abilities, and attitudes needed by a particular job and organization**. Many organizations use the term "**learning**" rather than "training" to emphasize that the activities are broad-based and involve much more than the straightforward acquisition of manual or technical skills. Training involves some kind of change for employees, such as changes in how they do their jobs, how they relate to others, or changes in their job responsibilities. Strategically targeted training in critical skills and knowledge bases adds to employee marketability and employability security.

The objectives of training include:

- **To increase the knowledge of employees or workers in doing specific jobs**.
- **To scientifically and systematically impart new skills** to human resources so that they learn quickly.
- **To bring about a change in the attitudes of the workers** towards fellow workers, supervisors, and the organization.
- **To improve the overall performance of the organization**.

The need for training arises due to various factors such as environmental changes like mechanization and automation, organizational complexity, the need to maintain good human relations, and to match employee specifications with job requirements and organizational needs.

**Various Techniques of Training:**

Training methods can be broadly classified into **on-the-job methods** and **off-the-job methods**.

**On-the-Job Methods:**

These methods are conducted in the actual work setting.

- **Job Rotation:** Employees are shifted between two or more assignments or jobs in a planned manner at regular intervals. This helps in **motivating employees** and allows them to **learn skills** across different verticals or horizontals of the organization.
- **Coaching:** This involves providing **feedback** to individuals, often executives, senior managers, and managers, about how to reach their personal best in their organizational leadership roles. HR professionals act as coaches by actively listening and providing assessments of strengths and weaknesses.
- **Job Instruction (JIT):** A simple form of on-the-job training where a **new employee is trained step by step by a supervisor or an assigned coworker**. This is typically used for jobs requiring manual skills and relatively low skill levels.
- **Committee Assignments:** Trainees are asked to **solve an actual organizational problem** by working together and offering solutions. This can provide a broadening experience and help them understand organizational dynamics.
- **Internship Training:** An arrangement between an educational or vocational institute and industrial enterprises to provide **experiential knowledge** to students or employees.

**Off-the-Job Methods:**

These methods are conducted away from the actual work setting, allowing learners to focus on their learning by minimizing interruptions.

- **Case Study Method:** Trainees are presented with a **detailed written description of a simulated or real-life decision-making scenario** and are expected to solve the problems using their decision-making and teamwork skills.
- **Incident Method:** Incidents based on **actual situations in different organizations** are prepared, and each employee in the training group makes decisions as if it were a real-life situation. The group then discusses the incident and takes decisions based on individual and group input.
- **Role Play:** A **problem situation is simulated**, and employees assume the roles of particular people in the situation, interacting with other participants. The performance can be recorded for self-examination.
- **In-Basket Method:** Employees are given information about an **imaginary company** and related data. They have to make notes, delegate tasks, and prepare schedules within a specified time to develop situational judgment and quick decision-making skills.
- **Business Games:** Trainees are divided into groups, and each group discusses various activities and functions of an **imaginary organization**, making decisions on aspects like production, promotion, and pricing, fostering cooperative decision-making.
- **Grid Training:** A **continuous and phased program** lasting several years, including planning, development, implementation, and evaluation, considering concern for people and concern for production.
- **Lectures:** Suitable when the number of trainees is large. Lectures are helpful for **explaining concepts and principles clearly** with face-to-face interaction possible.
- **Simulation:** An **imaginary situation is created**, and trainees are asked to act on it, such as assuming the role of a marketing manager solving problems. Simulation techniques aim to simulate what happens on the job, often using case studies, role plays, and interactive methods.
- **Management Education:** Universities and management institutes offer management education programs, often providing degrees and hands-on experience through collaborations with businesses.
- **Conferences:** Meetings where several people discuss a subject. Each participant contributes by analyzing and discussing various issues related to the topic, allowing everyone to express their viewpoints.

The "Strategic Human Resource Management" source also discusses different **modes of delivery** for training:

- **On the job**.
- **Off the job**.
- **Online (Computer-based instruction):** This method offers benefits such as being **self-paced**, adaptive to different needs, easy to deliver, and often less expensive, especially when employees are geographically dispersed. It also allows for training to be undertaken whenever it is convenient for the employee.

The choice of training techniques depends on the objectives of the training, the nature of the job, the number of employees to be trained, the resources available, and the learning styles of the trainees. Effective training programs strategically plan and choose methods that maximize learning and the transfer of knowledge and skills to the workplace.

---

# Unit-3

#### Q5 - Define Performance Appraisal? Explain the importance and process of Performance Appraisal.

**Performance Appraisal is the systematic evaluation of the performance of employees and to understand the abilities of a person for further growth and development**. It may also be defined as **the process of comparing an employee's performance with already established standards and providing them the feedback about their performance so that they can easily improve their performance**. Performance management, a broader term often used interchangeably or closely related to performance appraisal, is crucial for an organization's long-term success in meeting its strategic objectives by managing employee performance and ensuring performance measures align with organizational needs.

**Importance of Performance Appraisal:**

Performance appraisal is important for several reasons, serving various objectives for both the organization and its employees:

- **Maintaining Records for Compensation:** It helps **maintain records in order to determine compensation packages, wage structure, salaries raises, etc.**. Performance data is frequently used as a basis for salary, promotion, retention, and bonus decisions.
- **Identifying Strengths and Weaknesses:** It helps **identify the strengths and weaknesses of employees to place right men on right job**. By assessing deficiencies in performance levels and skills, organizations can determine specific training and development needs.
- **Assessing Potential for Growth and Development:** It serves **to maintain and assess the potential present in a person for further growth and development**.
- **Providing Feedback:** It is crucial to **provide a feedback to employees regarding their performance and related status**. This feedback helps employees identify their weak areas and initiate actions to overcome them, motivating them to perform better in the future. Effective performance management requires providing employees with meaningful information.
- **Influencing Working Habits:** It can **serve as a basis for influencing working habits of the employees**.
- **Reviewing for Promotion and Training:** It helps **review and retain the promotional and other training**.
- **Counseling Subordinates:** It provides information that **helps to counsel the subordinates**.
- **Diagnosing Deficiencies:** It assists in **getting information to diagnose deficiency in employees regarding skills, knowledge, etc.**.
- **Enhancing Motivation:** A formal process of acknowledgment and praise can **reinforce beneficial behaviors and outcomes**, and employees can be informed of organizational expectations.
- **Facilitating Legal Compliance:** Performance management systems can **facilitate legal compliance**.
- **Facilitating Human Resource Planning:** Performance data can **alert the organization to deficiencies in employee skills** and be used in planning for future staffing needs.
- **Linking to Business Objectives:** Effective performance management links employee work activities to specific business objectives and strategy.

**Process of Performance Appraisal:**

The process of performance appraisal typically involves the following steps:

1. **Setting the Performance Standards:** This is the first step and involves **defining the standards of performance expected from the employees**. These standards should align with the organization's objectives and mission and must be realistic and attainable.
2. **Communicating the Performance Standard to Employees:** Simply setting standards is insufficient; the **expected level of performance should be communicated to the employees** so they are aware of what is expected of them.
3. **Measuring the Actual Performance:** This crucial step involves **measuring the actual performances** of employees. Various methods exist for measuring performance.
4. **Comparing the Actual With the Standard Performance:** This comparison **determines the gap between the actual and the expected performance**. Identifying these gaps can inform training and development initiatives.
5. **Providing Feedback to Employees on Their Performance:** It is essential to **provide feedback to employees** on how their actual performance compares to the established standards. This helps them understand their strengths and weaknesses.
6. **Initiating Corrective Actions (if necessary):** When a gap exists between the actual and expected performance, **corrective actions should be undertaken** after analyzing the reasons for the gap. If the performance matches the standard, no corrective action is needed.

The "Strategic Human Resource Management" source further elaborates on strategic choices within the performance management system, including decisions on:

- **How the System Will Be Used:** Determining the primary purpose(s) of the system (e.g., employee development, rewards, motivation, legal compliance, HR planning).
- **Who Evaluates:** Deciding who will provide performance data (e.g., supervisor, peers, subordinates, customers, self).
- **What to Evaluate:** Determining what aspects of performance will be assessed (e.g., traits, behaviors, results).
- **How to Evaluate:** Choosing whether to use absolute measures (based on job standards) or relative measures (comparison to coworkers).
- **Means of Evaluation:** Selecting the specific tools or formats for measuring performance (e.g., graphic rating scales, checklists, BARS, MBO).
- **Link with Compensation and Training:** Ensuring the performance management system is integrated with the organization's training and development and compensation systems.
- **Flexibility/Standardization:** Balancing consistency and adaptability in the system based on job responsibilities.
- **Individual/Team:** Deciding whether to evaluate individual or team performance, or both.
- **Time Periods:** Considering past, present, and future performance in the management process.

#### Q6 - What do you mean by Grievance Handling? Also discuss its concept and need.

**Grievance handling** refers to the **formal and informal processes used by an organization to address and resolve employees' complaints or feelings of dissatisfaction** related to their employment. It encompasses the mechanisms and procedures established to allow employees to voice their concerns and seek remedies for perceived injustices.

**Concept of Grievance:**

A **grievance** is defined as **any real or imaginary feeling of dissatisfaction and injustice that an employee has about their employment**. Key aspects of this concept include:

- **Dissatisfaction and Discontentment:** A grievance stems from an employee's unhappiness or displeasure with some aspect of their job or work environment.
- **Professional Reasons:** The dissatisfaction should ideally be due to **professional reasons** rather than purely personal issues. This implies that the concern is related to the terms and conditions of employment, work tasks, supervision, organizational policies, or similar factors.
- **Feeling of Injustice:** A core element of a grievance is the employee's perception that they have been treated unfairly or that their rights have been violated. This feeling of injustice can be based on a misunderstanding, a misapplication of policies, or a genuine violation.
- **Verbal or Written:** Grievances can be expressed **verbally or in writing**. Organizations often have formal written procedures for submitting and processing grievances, especially at higher levels of management.
- **Real or Imaginary:** The source notes that a grievance can be based on a **real issue or an imaginary feeling**. This highlights the subjective nature of grievances and the importance of addressing even perceived injustices.

The sources also outline various **causes of grievances**, including:

- Working conditions
- Poor physical setting
- Unavailability of tools or raw materials
- Poor supervision
- Management policy
- Overtime payment issues
- Internal shifting
- Less career growth opportunities
- Personal maladjustment, including over-ambition and impractical attitudes
- Ineffective leadership
- Lack of a well-defined code of conduct
- Faulty supervision
- Partiality
- Late problem hearing or grievance handling
- Defective communication system
- Excessive workload
- Uninterested work
- Low wages
- Leave issues
- Trade union influences

**Need for Grievance Handling:**

Establishing and maintaining effective grievance handling procedures is crucial for several reasons:

- **Addressing Employee Dissatisfaction:** It provides a **formal avenue for employees to voice their concerns and dissatisfactions**. Without such mechanisms, discontent can fester, leading to decreased morale, reduced productivity, and potentially higher turnover.
- **Ensuring Fairness and Justice:** A well-defined grievance procedure can help ensure that **employees are treated fairly and consistently** according to organizational policies and collective bargaining agreements. It offers a process to review situations where employees feel unjustly treated.
- **Conflict Resolution:** Grievance procedures act as a **mechanism for resolving conflicts** between employees and management before they escalate into more serious issues like strikes or legal action.
- **Identifying Systemic Issues:** The patterns and types of grievances received can provide valuable **feedback to management about underlying problems** within the organization, such as ineffective policies, poor supervision, or inadequate working conditions. Addressing these issues can lead to organizational improvements.
- **Maintaining Positive Employee Relations:** By providing a fair and responsive grievance handling process, organizations can **demonstrate their commitment to employee well-being and foster a more positive and trusting work environment**. Treating union leaders equally in the process is also important.
- **Legal Compliance:** In unionized environments, **grievance procedures are often a mandatory part of the collective bargaining agreement**. Even in non-unionized settings, having a fair process can help mitigate the risk of legal challenges related to unfair treatment or wrongful termination.
- **Improving Collective Bargaining:** Grievance procedures can help **identify weaknesses or oversights in collective-bargaining agreements** that can be addressed during future negotiations.
- **Retention:** Employees who have a way to voice and resolve concerns may be **less likely to resign**. Addressing grievances can sometimes lead to retaining a valuable employee by resolving their issues.
- **Data Collection and Communication:** The grievance handling process, especially exit interviews, can provide **key insights into the effectiveness of the organization's HR strategy and branding initiatives**. It also serves as a channel for communication between employees and management.

In essence, grievance handling is a vital component of effective human resource management that contributes to organizational justice, positive employee relations, and overall organizational effectiveness. It provides a structured way to address workplace issues, ensuring that employee concerns are heard and resolved in a fair and timely manner.

---



