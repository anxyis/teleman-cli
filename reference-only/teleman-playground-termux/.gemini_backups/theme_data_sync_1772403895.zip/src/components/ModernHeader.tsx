import { DynamicIcon } from './common/DynamicIcon';
import { BotSelector } from './BotSelector';
import { useLocation } from 'react-router-dom';
import { AnimatedText } from './common/AnimatedText';

interface ModernHeaderProps {
  activeToken: string;
  savedBots: any[];
  onBotChange: () => void;
  onOpenSettings: () => void;
  position?: 'top' | 'bottom';
}

export function ModernHeader({ activeToken, savedBots, onBotChange, onOpenSettings, position = 'top' }: ModernHeaderProps) {
  const location = useLocation();

  let title = "TeleMan";
  if (location.pathname === '/') title = "Playground";
  else if (location.pathname === '/batch') title = "Batch"; // Shorter for mobile
  else if (location.pathname.startsWith('/autosyncer')) title = "Sync"; // Shorter for mobile

  const SettingsButton = ({ className }: { className?: string }) => (
    <button
      onClick={onOpenSettings}
      className={`p-2 text-text-muted hover:text-text-main hover:bg-surface-highlight rounded-xl transition-colors ${className}`}
      aria-label="Settings"
    >
      <DynamicIcon name={"settings" as any} size={20} />
    </button>
  );

  const isBottom = position === 'bottom';

  return (
    <header className={isBottom 
      ? "fixed bottom-6 left-0 right-0 z-50 flex justify-center px-6 pointer-events-none" 
      : "sticky top-0 z-50 bg-canvas/80 backdrop-blur-xl border-b border-border px-4 h-16 flex items-center justify-between transition-all duration-300"
    }>
       <div className={isBottom 
         ? "pointer-events-auto flex items-center gap-4 bg-surface/80 backdrop-blur-2xl border border-border/50 p-2 shadow-2xl rounded-full" 
         : "flex items-center gap-3 min-w-0"
       }>
           {/* Icon */}
           <div className="p-2 bg-primary/20 rounded-xl text-primary shrink-0">
             <DynamicIcon name={"terminal" as any} size={18} />
           </div>

           {/* Title */}
           <h1 className="font-bold text-base tracking-tight text-text-main truncate pr-2">
             <AnimatedText text={title} key={title} />
           </h1>

           {/* Inverted Actions */}
           {isBottom && (
             <div className="flex items-center gap-2 border-l border-border/50 pl-2">
                <BotSelector
                  currentBotToken={activeToken}
                  savedBots={savedBots}
                  onBotChange={onBotChange}
                  onOpenSettings={onOpenSettings}
                  isCompact={true}
                />
                <SettingsButton />
             </div>
           )}
       </div>

       {/* Top Bar Actions (only if NOT bottom) */}
       {!isBottom && (
         <div className="flex items-center gap-2 shrink-0">
             <div className="flex items-center gap-2">
               <BotSelector
                 currentBotToken={activeToken}
                 savedBots={savedBots}
                 onBotChange={onBotChange}
                 onOpenSettings={onOpenSettings}
                 isCompact={true}
               />
               <SettingsButton />
             </div>
         </div>
       )}
    </header>
  );
}
