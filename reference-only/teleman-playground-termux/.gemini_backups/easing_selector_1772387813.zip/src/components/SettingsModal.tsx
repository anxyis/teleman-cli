import { useState, useEffect } from 'react';
import {
    Download, Upload, AlertTriangle, CheckCircle, Loader2,
    ToggleLeft, ToggleRight, Bot, Trash2, Palette, Type,
    ChevronRight, ChevronLeft, Database, Network, Save, RefreshCw, Zap
} from 'lucide-react';
import axios from 'axios';
import { useTheme, type Theme } from '../context/ThemeContext';
import { ResponsiveModal } from './common/ResponsiveModal';
import { BetterColorPicker } from './common/BetterColorPicker';

interface SettingsModalProps {
    isOpen: boolean;
    onClose: () => void;
}

type SettingsView = 'root' | 'appearance' | 'fonts' | 'bot' | 'data' | 'network' | 'studio' | 'animations';

const FONT_OPTIONS = [
    { name: 'JetBrains Mono', value: 'JetBrains Mono' },
    { name: 'Inter', value: 'Inter' },
    { name: 'System Sans', value: 'system-ui' }
];

export function SettingsModal({ isOpen, onClose }: SettingsModalProps) {
    const { currentTheme, availableThemes, availableFonts, loadTheme, refreshThemes } = useTheme();
    const [view, setView] = useState<SettingsView>('root');
    const [editingTheme, setEditingTheme] = useState<Theme | null>(null);
    const [restoring, setRestoring] = useState(false);
    const [successMsg, setSuccessMsg] = useState<string | null>(null);
    const [errorMsg, setErrorMsg] = useState<string | null>(null);
    const [selectedFile, setSelectedFile] = useState<File | null>(null);

    const dynamicFontOptions = [
        ...FONT_OPTIONS,
        ...availableFonts.map(f => ({ name: f.split('.')[0], value: f.split('.')[0] }))
    ];

    // --- System & Animation Preferences ---
    const [showLogsButton, setShowLogsButton] = useState(() => localStorage.getItem('showLogsButton') !== 'false');
    const [fabMode, setFabMode] = useState(() => localStorage.getItem('fabMode') === 'true');
    
    // Animation Specifics
    const [syncAnimationsEnabled, setSyncAnimationsEnabled] = useState(() => localStorage.getItem('syncAnimationsEnabled') !== 'false');
    const [modalAnimEnabled, setModalAnimEnabled] = useState(() => localStorage.getItem('modalAnimEnabled') !== 'false');
    const [modalAnimStyle, setModalAnimStyle] = useState(() => localStorage.getItem('modalAnimStyle') || 'slide-left');
    const [modalAnimSpeed, setModalAnimSpeed] = useState(() => parseFloat(localStorage.getItem('modalAnimSpeed') || '0.3'));
    const [modalAnimBouncy, setModalAnimBouncy] = useState(() => localStorage.getItem('modalAnimBouncy') === 'true');

    // --- Bot Manager State ---
    const [savedBots, setSavedBots] = useState<any[]>([]);
    const [activeToken, setActiveToken] = useState("");
    const [newBotToken, setNewBotToken] = useState("");
    const [loadingBots, setLoadingBots] = useState(false);
    const [savingBot, setSavingBot] = useState(false);

    const [telegramApiUrl, setTelegramApiUrl] = useState("http://192.168.0.7:8181");

    const [fontPreview, setFontPreview] = useState({
        text: "ABCDEFGHIJKLM\nNOPQRSTUVWXYZ\n0123456789",
        use_font_sheet: false,
        bg_color: "#ffffff",
        text_color: "#000000",
        size: "medium",
        enabled: true
    });

    const API_BASE = '';

    // --- Effects ---
    useEffect(() => {
        localStorage.setItem('showLogsButton', String(showLogsButton));
        localStorage.setItem('fabMode', String(fabMode));
        localStorage.setItem('syncAnimationsEnabled', String(syncAnimationsEnabled));
        localStorage.setItem('modalAnimEnabled', String(modalAnimEnabled));
        localStorage.setItem('modalAnimStyle', modalAnimStyle);
        localStorage.setItem('modalAnimSpeed', String(modalAnimSpeed));
        localStorage.setItem('modalAnimBouncy', String(modalAnimBouncy));

        window.dispatchEvent(new CustomEvent('settingsChanged', { 
            detail: { showLogsButton, fabMode, syncAnimationsEnabled, modalAnimEnabled, modalAnimStyle, modalAnimSpeed, modalAnimBouncy } 
        }));
    }, [showLogsButton, fabMode, syncAnimationsEnabled, modalAnimEnabled, modalAnimStyle, modalAnimSpeed, modalAnimBouncy]);

    useEffect(() => {
        if (isOpen) {
            setView('root');
            fetchBots();
        }
    }, [isOpen]);

    useEffect(() => {
        if (isOpen && currentTheme) {
            setEditingTheme(JSON.parse(JSON.stringify(currentTheme)));
        }
    }, [isOpen, currentTheme]);

    // --- API & Actions ---
    const fetchBots = async () => {
        setLoadingBots(true);
        try {
            const res = await axios.get(`${API_BASE}/api/config`);
            setSavedBots(res.data.saved_bots || []);
            setActiveToken(res.data.active_token || "");
            if (res.data.font_preview) setFontPreview(res.data.font_preview);
            if (res.data.telegram_api_url) setTelegramApiUrl(res.data.telegram_api_url);
        } catch (e) { console.error("Failed to fetch config", e); }
        finally { setLoadingBots(false); }
    };

    const handleSaveBot = async () => {
        if (!newBotToken) return;
        setSavingBot(true); setErrorMsg(null);
        try {
            const res = await axios.post(`${API_BASE}/api/bots`, { token: newBotToken, set_active: true });
            setSavedBots(res.data.saved_bots || []);
            setActiveToken(res.data.active_token || "");
            setNewBotToken("");
            setSuccessMsg(`Bot added and activated!`);
        } catch (e: any) { setErrorMsg(e.response?.data?.description || "Failed to save bot"); }
        finally { setSavingBot(false); }
    };

    const handleDeleteBot = async (token: string) => {
        if (!confirm("Are you sure?")) return;
        try {
            const res = await axios.delete(`${API_BASE}/api/bots/${encodeURIComponent(token)}`);
            setSavedBots(res.data.saved_bots || []);
            setActiveToken(res.data.active_token || "");
        } catch { setErrorMsg("Failed to remove bot"); }
    };

    const handleActivateBot = async (token: string) => {
        const bot = savedBots.find(b => b.token === token);
        if (!bot) return;
        try {
            const res = await axios.post(`${API_BASE}/api/bots`, { name: bot.name, token: bot.token, set_active: true });
            setActiveToken(res.data.active_token || "");
            setSuccessMsg(`Switched to ${bot.name}`);
        } catch { setErrorMsg("Failed to switch bot"); }
    };

    const saveFontSettings = async () => {
        try {
            await axios.post(`${API_BASE}/api/config/font`, fontPreview);
            setSuccessMsg("Font settings saved!");
        } catch { setErrorMsg("Failed to save font settings."); }
    };

    const saveNetworkSettings = async () => {
        try {
            await axios.post(`${API_BASE}/api/config/network`, { telegram_api_url: telegramApiUrl });
            setSuccessMsg("Network settings saved!");
        } catch { setErrorMsg("Failed to save network settings."); }
    };

    const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            setSelectedFile(e.target.files[0]);
            setErrorMsg(null);
        }
    };

    const handleRestore = async () => {
        if (!selectedFile) return;
        if (!confirm("Restore backup?")) return;
        setRestoring(true); setErrorMsg(null); setSuccessMsg(null);
        const formData = new FormData(); formData.append('backup', selectedFile);
        try {
            const res = await axios.post(`${API_BASE}/api/restore`, formData, { headers: { 'Content-Type': 'multipart/form-data' } });
            if (res.data.success) {
                setSuccessMsg("Restore successful!");
                setSelectedFile(null);
            }
        } catch (e: any) { setErrorMsg(e.response?.data?.error || "Restore failed."); }
        finally { setRestoring(false); }
    };

    const handleDownloadBackup = () => { window.open(`${API_BASE}/api/backup`, '_blank'); };

    const handleSaveTheme = async (isReset = false) => {
        if (!editingTheme) return;
        setSuccessMsg(null); setErrorMsg(null);
        try {
            const themeToSave = isReset ? availableThemes.find((t: any) => t.id === editingTheme.id) : editingTheme;
            if (!themeToSave) return;
            await axios.post(`${import.meta.env.VITE_API_BASE_URL ?? ''}/api/themes/save`, themeToSave);
            await refreshThemes();
            await loadTheme(themeToSave.id);
            setSuccessMsg(`Theme saved!`);
        } catch (e) { setErrorMsg("Failed to save theme"); }
    };

    const updateToken = (path: string, value: string | boolean) => {
        if (!editingTheme) return;
        const newTheme = { ...editingTheme };
        const parts = path.split('.');
        let current: any = newTheme.tokens;
        for (let i = 0; i < parts.length - 1; i++) { current = current[parts[i]]; }
        current[parts[parts.length - 1]] = value;
        setEditingTheme(newTheme);
        
        const category = parts[0]; 
        const tokenName = parts[parts.length - 1];
        const cssKey = tokenName.replace(/[A-Z]/g, m => "-" + m.toLowerCase());
        
        if (category === 'colors') document.documentElement.style.setProperty(`--${cssKey}`, value as string);
        else if (category === 'radii') document.documentElement.style.setProperty(`--radius-${cssKey}`, value as string);
        else if (category === 'typography') {
             if (tokenName === 'fontFamily') document.documentElement.style.setProperty('--font-family', value as string);
             if (tokenName === 'baseSize') document.documentElement.style.setProperty('--font-size-base', value as string);
             if (tokenName === 'headingWeight') document.documentElement.style.setProperty('--heading-weight', value as string);
        } else if (category === 'icons') {
             if (tokenName === 'strokeWidth') document.documentElement.style.setProperty('--icon-stroke', value as string);
        } else if (category === 'effects') {
             if (tokenName === 'glassOpacity') document.documentElement.style.setProperty('--glass-opacity', value as string);
             if (tokenName === 'shadowCard') document.documentElement.style.setProperty('--shadow-card', value as string);
             if (tokenName === 'glow') document.documentElement.style.setProperty('--glow-opacity', value ? '0.2' : '0');
        }
    };

    // --- Render Functions ---

    const MenuTile = ({ icon: Icon, title, desc, onClick, colorClass = "text-primary" }: any) => (
        <button onClick={onClick} className="w-full flex items-center gap-4 p-4 hover:bg-surface-highlight/50 transition-colors border-b border-border/50 first:rounded-t-lg last:border-0 text-left group">
            <div className={`p-2.5 rounded-xl bg-surface-highlight group-hover:bg-surface transition-colors ${colorClass.replace('text-', 'bg-').replace('400', '500/10')} ${colorClass}`}><Icon size={22} /></div>
            <div className="flex-1"><h3 className="text-base font-medium text-text-main">{title}</h3><p className="text-xs text-text-muted mt-0.5">{desc}</p></div>
            <ChevronRight size={18} className="text-text-muted group-hover:text-text-main transition-colors" />
        </button>
    );

    const renderRoot = () => (
        <div className="bg-surface rounded-xl border border-border overflow-hidden">
            <MenuTile icon={Palette} title="Appearance" desc="Theme, Fonts, Animations" onClick={() => setView('appearance')} colorClass="text-purple-400" />
            <MenuTile icon={Type} title="Font Previews" desc="Generator Settings, Backgrounds" onClick={() => setView('fonts')} colorClass="text-pink-400" />
            <MenuTile icon={Bot} title="Bot Manager" desc="Tokens, Active Bot" onClick={() => setView('bot')} colorClass="text-blue-400" />
            <MenuTile icon={Network} title="Network" desc="API Endpoints, Connection" onClick={() => setView('network')} colorClass="text-green-400" />
            <MenuTile icon={Database} title="Data & Storage" desc="Backup, Restore, Logs" onClick={() => setView('data')} colorClass="text-orange-400" />
        </div>
    );

    const renderAppearance = () => (
        <div className="space-y-6">
            <div className="bg-canvas/50 p-4 rounded-xl border border-border space-y-4">
                <div>
                    <p className="text-text-main font-bold text-xs uppercase tracking-widest mb-3">Active Theme</p>
                    <div className="grid grid-cols-2 gap-2">
                        {availableThemes.map((t: any) => (
                            <button key={t.id} onClick={() => loadTheme(t.id)} className={`p-3 rounded-lg border text-sm font-medium transition-all text-left flex flex-col gap-1 ${currentTheme?.id === t.id ? 'bg-primary/10 border-primary text-primary' : 'bg-surface border-border text-text-muted hover:border-border/80'}`}>
                                <span>{t.name}</span><span className="text-[10px] opacity-60 uppercase">{t.type}</span>
                            </button>
                        ))}
                    </div>
                </div>
                <div className="pt-2 space-y-2">
                    <button onClick={() => setView('studio')} className="w-full flex items-center justify-between p-4 bg-primary/10 hover:bg-primary/20 border border-primary/20 rounded-xl transition-all group">
                        <div className="flex items-center gap-3 text-primary"><Palette size={20} /><div className="text-left"><p className="text-sm font-bold">Theme Studio</p><p className="text-[10px] opacity-80">Customize colors, shapes and fonts</p></div></div>
                        <ChevronRight size={18} className="text-primary group-hover:translate-x-1 transition-transform" />
                    </button>
                    <button onClick={() => setView('animations')} className="w-full flex items-center justify-between p-4 bg-blue-500/10 hover:bg-blue-500/20 border border-blue-500/20 rounded-xl transition-all group">
                        <div className="flex items-center gap-3 text-blue-400"><Zap size={20} /><div className="text-left"><p className="text-sm font-bold">Animations Studio</p><p className="text-[10px] opacity-80">Control UI motion and effects</p></div></div>
                        <ChevronRight size={18} className="text-blue-400 group-hover:translate-x-1 transition-transform" />
                    </button>
                </div>
                <hr className="border-border/50" />
                <div className="flex items-center justify-between"><div><p className="text-text-main font-medium">Show Logs Button</p><p className="text-xs text-text-muted">Display debug logs button on dashboard</p></div><button onClick={() => setShowLogsButton(!showLogsButton)} className={`p-1 rounded-lg transition-colors ${showLogsButton ? 'text-green-400' : 'text-text-muted'}`}>{showLogsButton ? <ToggleRight size={32} /> : <ToggleLeft size={32} />}</button></div>
                <div className="flex items-center justify-between pt-2 border-t border-border/50"><div><p className="text-text-main font-medium">Floating Add Button</p><p className="text-xs text-text-muted">Move "New Sync" button to bottom right</p></div><button onClick={() => setFabMode(!fabMode)} className={`p-1 rounded-lg transition-colors ${fabMode ? 'text-primary' : 'text-text-muted'}`}>{fabMode ? <ToggleRight size={32} /> : <ToggleLeft size={32} />}</button></div>
            </div>
        </div>
    );

    const renderAnimations = () => (
        <div className="space-y-6">
            <div className="bg-canvas/50 p-4 rounded-xl border border-border space-y-6">
                <div className="flex items-center justify-between pb-4 border-b border-border/50"><div><p className="text-text-main font-bold">Modal Entry Animations</p><p className="text-xs text-text-muted">Master control for global menu transitions</p></div><button onClick={() => setModalAnimEnabled(!modalAnimEnabled)} className={`p-1 rounded-lg transition-colors ${modalAnimEnabled ? 'text-primary' : 'text-text-muted'}`}>{modalAnimEnabled ? <ToggleRight size={32} /> : <ToggleLeft size={32} />}</button></div>
                {modalAnimEnabled && (
                    <div className="space-y-6 animate-in fade-in slide-in-from-top-2 duration-300">
                        <div className="space-y-2"><label className="text-[10px] font-bold text-text-muted uppercase tracking-widest">Entry Style</label><div className="grid grid-cols-2 gap-2">{[{ id: 'slide-left', label: 'Slide Left' }, { id: 'slide-right', label: 'Slide Right' }, { id: 'slide-up', label: 'Slide Up' }, { id: 'scale', label: 'Scale Up' }].map(s => (<button key={s.id} onClick={() => setModalAnimStyle(s.id)} className={`px-3 py-2 text-xs font-medium border rounded-lg transition-all ${modalAnimStyle === s.id ? 'bg-primary/10 border-primary text-primary' : 'bg-surface border-border text-text-muted hover:border-border/80'}`}>{s.label}</button>))}</div></div>
                        <div className="space-y-3"><div className="flex justify-between items-center"><label className="text-[10px] font-bold text-text-muted uppercase tracking-widest">Speed</label><span className="text-[10px] font-mono text-primary">{modalAnimSpeed}s</span></div><input type="range" min="0.1" max="1.0" step="0.05" value={modalAnimSpeed} onChange={e => setModalAnimSpeed(parseFloat(e.target.value))} className="w-full h-2 bg-surface-highlight rounded-lg appearance-none cursor-pointer accent-primary" /></div>
                        <div className="flex items-center justify-between bg-surface-highlight/30 p-3 rounded-xl border border-border/50"><div className="flex items-center gap-3"><div className="p-2 rounded-lg bg-blue-500/10 text-blue-400"><RefreshCw size={16} className={modalAnimBouncy ? "animate-spin-slow" : ""} /></div><div><p className="text-xs font-bold text-text-main">Bouncy Physics</p><p className="text-[10px] text-text-muted">Use high-stiffness spring engine</p></div></div><button onClick={() => setModalAnimBouncy(!modalAnimBouncy)} className={`transition-colors ${modalAnimBouncy ? 'text-blue-400' : 'text-text-muted'}`}>{modalAnimBouncy ? <ToggleRight size={32} /> : <ToggleLeft size={32} />}</button></div>
                    </div>
                )}
                <hr className="border-border/50" />
                <div className="flex items-center justify-between"><div><p className="text-text-main font-medium">Sync Card Animations</p><p className="text-xs text-text-muted">Cards slide up when scrolled into view</p></div><button onClick={() => setSyncAnimationsEnabled(!syncAnimationsEnabled)} className={`p-1 rounded-lg transition-colors ${syncAnimationsEnabled ? 'text-primary' : 'text-text-muted'}`}>{syncAnimationsEnabled ? <ToggleRight size={32} /> : <ToggleLeft size={32} />}</button></div>
            </div>
        </div>
    );

    const renderStudio = () => {
        if (!editingTheme) return null;
        return (
            <div className="space-y-6">
                <div className="space-y-8 max-h-[500px] overflow-y-auto overscroll-contain pr-2 custom-scrollbar">
                    <section className="space-y-4"><div className="flex items-center gap-2"><Palette size={14} className="text-primary" /><h5 className="text-[10px] font-bold text-text-muted uppercase tracking-widest">Colors & Branding</h5></div><div className="grid grid-cols-2 gap-x-4 gap-y-3">{Object.entries(editingTheme.tokens.colors).map(([key, value]) => (<BetterColorPicker key={key} label={key} color={value} onChange={(newColor) => updateToken(`colors.${key}`, newColor)} />))}</div></section>
                    <section className="space-y-4"><div className="flex items-center gap-2"><Database size={14} className="text-blue-400" /><h5 className="text-[10px] font-bold text-text-muted uppercase tracking-widest">Shape & Layout</h5></div><div className="space-y-4 px-1"><div className="flex items-center justify-between bg-surface-highlight/50 p-3 rounded-xl border border-border/50"><div className="flex items-center gap-2"><div className="p-1.5 rounded-lg bg-primary/10 text-primary"><RefreshCw size={14} className={editingTheme.tokens.effects.glow ? "animate-pulse" : ""} /></div><div><p className="text-xs font-bold text-text-main">Glow FX</p><p className="text-[10px] text-text-muted">Toggle UI shadows and glows</p></div></div><button onClick={() => updateToken('effects.glow', !editingTheme.tokens.effects.glow)} className={`transition-colors ${editingTheme.tokens.effects.glow ? 'text-primary' : 'text-text-muted'}`}>{editingTheme.tokens.effects.glow ? <ToggleRight size={32} /> : <ToggleLeft size={32} />}</button></div>{Object.entries(editingTheme.tokens.radii).map(([key, value]) => (<div key={key} className="space-y-2"><div className="flex justify-between items-center px-1"><span className="text-[10px] text-text-muted font-bold uppercase tracking-wider">{key} Radius</span><span className="text-[10px] font-mono text-primary bg-primary/10 px-1.5 py-0.5 rounded">{value}</span></div><input type="range" min="0" max="40" value={parseInt(value) || 0} onChange={(e) => updateToken(`radii.${key}`, `${e.target.value}px`)} className="w-full h-3 bg-surface-highlight rounded-lg appearance-none cursor-pointer accent-primary theme-slider" /></div>))}</div></section>
                    <section className="space-y-4"><div className="flex items-center gap-2"><Type size={14} className="text-pink-400" /><h5 className="text-[10px] font-bold text-text-muted uppercase tracking-widest">Typography & Icons</h5></div><div className="space-y-4"><div className="space-y-2"><div className="flex justify-between items-center"><span className="text-[10px] text-text-muted uppercase tracking-wider font-bold">UI Text Size</span><span className="text-[10px] font-mono text-primary">{editingTheme.tokens.typography.baseSize}</span></div><input type="range" min="12" max="20" step="1" value={parseInt(editingTheme.tokens.typography.baseSize)} onChange={(e) => updateToken('typography.baseSize', `${e.target.value}px`)} className="w-full h-3 bg-surface-highlight rounded-lg appearance-none cursor-pointer accent-primary theme-slider" /></div><div className="flex flex-col gap-2"><span className="text-[10px] text-text-muted uppercase tracking-wider font-bold">Main Font Family</span><select value={dynamicFontOptions.find(f => f.value === editingTheme.tokens.typography.fontFamily)?.value || dynamicFontOptions[0].value} onChange={(e) => updateToken('typography.fontFamily', e.target.value)} className="w-full bg-surface-highlight border-none rounded-xl px-4 py-3 text-sm text-text-main outline-none focus:ring-1 focus:ring-primary/50">{dynamicFontOptions.map(font => (<option key={font.name} value={font.value}>{font.name}</option>))}</select></div><div className="space-y-2"><div className="flex justify-between items-center"><span className="text-[10px] text-text-muted uppercase tracking-wider font-bold">Icon Stroke Weight</span><span className="text-[10px] font-mono text-primary">{editingTheme.tokens.icons.strokeWidth}</span></div><input type="range" min="1" max="3" step="0.1" value={editingTheme.tokens.icons.strokeWidth} onChange={(e) => updateToken('icons.strokeWidth', e.target.value)} className="w-full h-3 bg-surface-highlight rounded-lg appearance-none cursor-pointer accent-primary theme-slider" /></div></div></section>
                </div>
                <div className="flex gap-2 pt-4 border-t border-border"><button onClick={() => handleSaveTheme(true)} className="px-4 py-2.5 bg-surface-highlight hover:bg-surface text-text-muted hover:text-text-main rounded-xl font-bold text-sm transition-all">Reset</button><button onClick={() => handleSaveTheme(false)} className="flex-1 flex items-center justify-center gap-2 bg-primary hover:bg-primary-hover text-on-primary py-2.5 rounded-xl font-bold text-sm shadow-lg shadow-primary/[var(--glow-opacity,0.20)] transition-all active:scale-95"><Save size={16} /> Save</button></div>
            </div>
        );
    };

    const renderFonts = () => (
        <div className="space-y-6">
            <div className="bg-canvas/50 p-4 rounded-lg border border-border space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-border/50"><div><p className="text-text-main font-medium text-sm">Enable Font Previews</p><p className="text-[10px] text-text-muted">Generate preview images</p></div><button onClick={() => setFontPreview({ ...fontPreview, enabled: !fontPreview.enabled })} className={`p-1 rounded-lg transition-colors ${fontPreview.enabled ? 'text-primary' : 'text-text-muted'}`}>{fontPreview.enabled ? <ToggleRight size={32} /> : <ToggleLeft size={32} />}</button></div>
                {fontPreview.enabled && (
                    <div className="space-y-4 animate-in fade-in slide-in-from-top-2 duration-300">
                        <div className="flex items-center justify-between"><div><p className="text-text-main font-medium text-sm">Font Sheet Mode</p></div><button onClick={() => setFontPreview({ ...fontPreview, use_font_sheet: !fontPreview.use_font_sheet })} className={`p-1 rounded-lg transition-colors ${fontPreview.use_font_sheet ? 'text-primary' : 'text-text-muted'}`}>{fontPreview.use_font_sheet ? <ToggleRight size={28} /> : <ToggleLeft size={28} />}</button></div>
                        {!fontPreview.use_font_sheet && (<textarea className="w-full bg-surface border border-border rounded-lg p-3 text-sm font-mono h-20 outline-none" value={fontPreview.text} onChange={e => setFontPreview({ ...fontPreview, text: e.target.value })} />)}
                        <div className="grid grid-cols-2 gap-4"><BetterColorPicker label="BG" color={fontPreview.bg_color} onChange={(c) => setFontPreview({ ...fontPreview, bg_color: c })} /><BetterColorPicker label="Text" color={fontPreview.text_color} onChange={(c) => setFontPreview({ ...fontPreview, text_color: c })} /></div>
                        <button onClick={saveFontSettings} className="w-full py-2 bg-surface-highlight text-text-main rounded-lg text-sm">Save Font Settings</button>
                    </div>
                )}
            </div>
        </div>
    );

    const renderBot = () => (
        <div className="space-y-6">
            <div className="bg-canvas/50 p-4 rounded-lg border border-border space-y-4">
                <div className="space-y-2">
                    <h4 className="text-xs font-bold text-text-muted uppercase">Saved Bots</h4>
                    {loadingBots ? (<div className="flex items-center gap-2 text-text-muted text-sm"><Loader2 className="animate-spin" size={14} /> Loading...</div>) : (
                        <div className="space-y-2">
                            {savedBots.map((bot, idx) => (
                                <div key={idx} className={`flex items-center justify-between p-3 rounded-lg border transition-all ${activeToken === bot.token ? 'bg-primary/10 border-primary/50' : 'bg-surface border-border'}`}>
                                    <div className="flex items-center gap-3"><div className={`w-8 h-8 rounded-full overflow-hidden shrink-0 flex items-center justify-center ${activeToken === bot.token ? 'bg-primary text-on-primary' : 'bg-surface-highlight text-text-muted'}`}>{bot.avatar_filename ? (<img src={`/api/avatars/${bot.avatar_filename}`} alt={bot.name} className="w-full h-full object-cover" />) : (<Bot size={16} />)}</div><div><p className={`text-sm font-medium ${activeToken === bot.token ? 'text-primary' : 'text-text-main'}`}>{bot.name}</p></div></div>
                                    <div className="flex items-center gap-2">{activeToken !== bot.token && <button onClick={() => handleActivateBot(bot.token)} className="text-xs bg-surface-highlight text-text-main px-2 py-1 rounded">Select</button>}<button onClick={() => handleDeleteBot(bot.token)} className="text-text-muted hover:text-red-400 p-1"><Trash2 size={14} /></button></div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
                <div className="border-t border-border pt-4 space-y-3">
                    <input type="text" placeholder="Bot Token" className="w-full bg-surface border border-border rounded px-3 py-2 text-sm outline-none" value={newBotToken} onChange={e => setNewBotToken(e.target.value)} /><button onClick={handleSaveBot} disabled={!newBotToken || savingBot} className="w-full py-2 bg-primary text-on-primary text-sm font-medium rounded">Add Bot</button>
                </div>
            </div>
        </div>
    );

    const renderNetwork = () => (
        <div className="space-y-6">
            <div className="bg-canvas/50 p-4 rounded-lg border border-border space-y-4">
                <div><label className="text-xs text-text-muted font-bold uppercase mb-1 block">Telegram API URL</label><input type="text" className="w-full bg-surface border border-border rounded px-3 py-2 text-sm outline-none" value={telegramApiUrl} onChange={e => setTelegramApiUrl(e.target.value)} placeholder="http://192.168.0.7:8181" /><p className="text-[10px] text-text-muted mt-1">For self-hosted API.</p></div>
                <button onClick={saveNetworkSettings} className="w-full py-2 bg-surface-highlight text-text-main rounded-lg text-sm">Save Network Settings</button>
            </div>
        </div>
    );

    const renderData = () => (
        <div className="space-y-6">
            <div className="bg-canvas/50 p-4 rounded-lg border border-border"><div className="flex items-center gap-2 mb-4 text-text-main font-semibold"><Download size={20} className="text-green-400" /> Backup System</div><button onClick={handleDownloadBackup} className="w-full py-2 bg-surface-highlight text-text-main rounded-lg text-sm">Download Backup</button></div>
            <div className="bg-canvas/50 p-4 rounded-lg border border-border"><div className="flex items-center gap-2 mb-4 text-text-main font-semibold"><Upload size={20} className="text-red-400" /> Restore Backup</div><input type="file" accept=".zip" onChange={handleFileSelect} className="block w-full text-sm text-text-muted mb-3" /><button onClick={handleRestore} disabled={!selectedFile || restoring} className={`w-full py-2 rounded-lg font-bold ${!selectedFile ? 'bg-surface-highlight text-text-muted' : 'bg-red-600 text-white'}`}>{restoring ? 'Restoring...' : 'Restore Now'}</button></div>
        </div>
    );

    const getTitle = () => {
        if (view === 'root') return 'Settings';
        if (view === 'appearance') return 'Appearance';
        if (view === 'studio') return 'Theme Studio';
        if (view === 'animations') return 'Animations Studio';
        if (view === 'fonts') return 'Font Generator';
        if (view === 'bot') return 'Bot Manager';
        if (view === 'data') return 'Data & Storage';
        if (view === 'network') return 'Network';
        return 'Settings';
    };

    return (
        <ResponsiveModal isOpen={isOpen} onClose={onClose} title={getTitle()} widthClass="max-w-lg" actions={null}>
            <div className="space-y-4">
                {view !== 'root' && (<button onClick={() => { if (view === 'studio' || view === 'animations') setView('appearance'); else setView('root'); }} className="mb-4 flex items-center gap-2 text-sm text-text-muted hover:text-text-main transition-colors w-fit"><ChevronLeft size={16} /> Back</button>)}
                <div className="flex-1 min-h-[300px]">
                    {view === 'root' && renderRoot()}
                    {view === 'appearance' && renderAppearance()}
                    {view === 'studio' && renderStudio()}
                    {view === 'animations' && renderAnimations()}
                    {view === 'fonts' && renderFonts()}
                    {view === 'bot' && renderBot()}
                    {view === 'network' && renderNetwork()}
                    {view === 'data' && renderData()}
                    {(successMsg || errorMsg) && (<div className={`mt-4 p-4 rounded-lg flex items-start gap-3 border animate-in slide-in-from-bottom-2 ${successMsg ? 'bg-green-500/10 border-green-500/30 text-green-400' : 'bg-red-500/10 border-red-500/30 text-red-400'}`}>{successMsg ? <CheckCircle size={20} className="mt-0.5" /> : <AlertTriangle size={20} className="mt-0.5" />}<p className="text-sm font-bold">{successMsg || errorMsg}</p></div>)}
                </div>
            </div>
        </ResponsiveModal>
    );
}
